const Discord = require('discord.js');


exports.run = function(client, message) {
const embed = new Discord.RichEmbed()
.setColor('Blue')
.setTitle('Sayaç Komutları')
.setTimestamp()
.addField('r!sayaç-ayarla','Sayaç Kanal ve Sayıyı Ayarlarsınız.')
.addField('r!sayaç-sıfırla','Sayaçı Sıfırlarsınız.')
.setFooter('Refox Bot | Sayaç Sistemi.')
.setTimestamp()
.setThumbnail(client.user.avatarURL)
message.channel.send(embed)
};

exports.conf = {
  enabled: true,
  guildOnly: false, 
  aliases: [], 
  permLevel: 0 
};

exports.help = {
  name: 'r!sayaç-sistemi',
  description: 'Tüm komutları gösterir.',
  usage: 'r!yardım'
};