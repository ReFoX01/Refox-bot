const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');
var prefix = ayarlar.prefix;
exports.run = (client, message, args) => {
  
    const juke = new Discord.RichEmbed()
    .setColor('GOLD')
    .setAuthor(`Refox BOT | Kullanıcı Komutları`, client.user.avatarURL) 
      .setDescription('**[Website](Yakında!)**')
.setThumbnail(client.user.avatarURL)
      .addField('**Komutlar:**', ' `bulanik`, `davet-oluştur`, `ping`, `avatar`, `kullanıcı-bilgi`')
    .setFooter(``, client.user.avatarURL)
    .setTimestamp()
    message.channel.send(juke).catch()

};

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: 0
};

exports.help = {
    name: 'kullanıcı',
      category: 'Yardım',
      description: 'Yardım kategorilerini gösteir.',
};