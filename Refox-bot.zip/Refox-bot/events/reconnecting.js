module.exports = client => {
  console.log(`> Refox Bot: Yeniden başlatılıyor Reis ${new Date()}`);
};
