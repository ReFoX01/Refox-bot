module.exports = member => {
    let username = member.user.username;
    member.send('Hoş Geldin! **' + username + '**!');
    member.guild.defaultChannel.send('hg '+username+'');
};

