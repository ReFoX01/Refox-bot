module.exports = member => {
  let guild = member.guild;
  member.send('Nereye ve niye gittin? Bir Daha Tekrar Gelirsin Umarım.');
  guild.defaultChannel.send(`${member.user.username} gitti.`);
};
