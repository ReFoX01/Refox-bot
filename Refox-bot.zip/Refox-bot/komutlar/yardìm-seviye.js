const Discord = require('discord.js');


exports.run = function(client, message) {
const embed = new Discord.RichEmbed()
.setColor('Blue')
.setTitle('Seviye Komutları')
.setTimestamp()
.addField('r!seviye','Seviyenizi atar.')
.addField('r!seviye-ayarlar','seviye komutlarının sunucudaki ayarlarını atar.')
.addField('r!seviye-aç','Seviye Sistemini açarsınız.')
.addField('r!seviye-kapat','Seviye sistemini kapatırsınız.')
.addField('r!seviye-log','Level atlayan kullanıcıları bu kanala atar.')
.addField('r!seviye-rol','Seviye ödülünü ayarlarsınız.')
.addField('r!seviye-xp','mesaj başına gelecek puanı ayarlarsınız.')
.setFooter('Refox Bot | Seviye Sistemi.')
.setTimestamp()
.setThumbnail(client.user.avatarURL)
message.channel.send(embed)
};

exports.conf = {
  enabled: true,
  guildOnly: false, 
  aliases: [], 
  permLevel: 0 
};

exports.help = {
  name: 'seviye-sistemi',
  description: 'Tüm komutları gösterir.',
  usage: 'r!yardım'
};