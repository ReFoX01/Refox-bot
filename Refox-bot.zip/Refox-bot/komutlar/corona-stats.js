const Discord = require('discord.js');
const NovelCovid = require("novelcovid");
exports.run = async (client, message, args) => {
  let compac = args.join(" ")
  if(!compac) return message.reply('Lütfen **dünya** veya **ülke adı** gir.')
 
 if(compac === "dünya") {
      let compacc = await NovelCovid.all() //it will give global cases
      
      let embed = new Discord.RichEmbed()
      .setAuthor(`DÜNYA BİLGİSİ`)
      .setColor("#ff2050")
      .setTitle("Refox-Bot| Korona istatistikleri!")
      .addField("Toplam Vaka", compacc.cases, true)
      .addField("Toplam Ölen", compacc.deaths, true)
      .addField("Toplam İyleşen", compacc.recovered, true)
      .addField("Bugünün Vakaları", compacc.todayCases, true)
      .addField("Bugün Ölenler", compacc.todayDeaths, true)
      .addField("Aktif Vakalar", compacc.active, true);
      
      return message.channel.send(embed)
      
      
      
    } else {
      let compac = await NovelCovid.countries(compac) 
      
      let embed = new Discord.RichEmbed()
      .setAuthor(`${compac.country}`)
      .setColor("#ff2050")
      .addField("Toplam Vaka", compac.cases, true)
      .addField("Toplam Ölen",compac.deaths, true)
      .addField("Toplam İyleşen", compac.recovered, true)
      .addField("Bugünün Vakaları", compac.todayCases, true)
      .addField("Bugün Ölenler", compac.todayDeaths, true)
      .addField("Aktif Vakalar", compac.active, true);
      
      return message.channel.send(embed)
      
      
    }
 
}; 
exports.conf = {
  enabled: false,
  guildOnly: false,
  aliases: ['koronaistatistik','korona'],
  permLevel: 0
};
exports.help = {
  name: 'korona-istatistik',
  usage: 'r!korona-istatistik'
};